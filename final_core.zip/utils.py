def clean_string(s):
    return s.strip().lower().replace(" ", "-")