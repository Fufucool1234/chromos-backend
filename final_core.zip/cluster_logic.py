def cluster_tags(tags):
    return {"Cluster 1": tags}