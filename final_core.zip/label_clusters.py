def label_clusters(clusters):
    return [f"Cluster {i+1}" for i in range(len(clusters))]