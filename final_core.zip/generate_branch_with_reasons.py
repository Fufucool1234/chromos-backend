def generate_branch(prompt):
    # Dummy color branch generator
    return [
        {
            "hex": "#123456",
            "name": "Dummy Color",
            "reason": f"Generated based on prompt '{prompt}'."
        }
    ]